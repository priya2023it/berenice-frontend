import React from "react"

const SearchBar = () => {
 return <></>
}

export default SearchBar

import PagesRoutes from "./pages"
const TemplateTitle = "Berenice Admin Panel"

const Routes = PagesRoutes

export { TemplateTitle, Routes }
